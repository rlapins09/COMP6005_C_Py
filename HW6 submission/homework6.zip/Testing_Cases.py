# homework 6: Computting for Engineers
# Elana Lapins , 11/3/2021

cases = int(input());

for i in range(cases):
    print("Case ",i,":\n")
    out = input();
    print("Echo: ",out,"\n")