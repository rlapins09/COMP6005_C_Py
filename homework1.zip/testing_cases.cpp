// HW 1 Problem 0: Testing Cases
// Elana Lapins 9/4/2021

#include <iostream>
#include<string>
using namespace std;


int main() {
	for (int a = 0; a < 1; a++) {
		int cases;
		std::cin >> cases;

		for (int i = 0; i < cases; i++) {
			std::string word;
			std::cin >> word;
			std::cout << "Case " << i << ":\n";
			std::cout << "Echo: " << word << "\n";
		}
	}
}