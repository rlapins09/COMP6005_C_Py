#include <iostream>
#include <string>

int main() {
	for (int a = 0; a < 1; a++) {
		int cases;
		std::cin >> cases;
		short start = 32000; //boss health starts at 32000

		for (int i = 0; i < cases; i++) {
			short bossHealth;
			short player;
			//short start = 32000; //boss health starts at 32000
			std::cin >> player;

			//bossHealth = start + player;

			//Negative or 0 case
			if (player < -start) {
				std::cout << "Case " << i << ":\n";
				std::cout << "boss health is " << 0 << "\n";
				std::cout << "the boss is dead!\n";
			}
			// overflow case
			else if (player >= 767) {
				std::cout << "Case " << i << ":\n";
				std::cout << "no healing the boss to kill it!\n";
				std::cout << "boss health is " << 32767 << "\n";
			}
			// OK cases between short [-32767 32767]
			else {
				std::cout << "Case " << i << ":\n";
				bossHealth = start + player;
				std::cout << "boss health is " << bossHealth << "\n";
			}
		}
	}

}